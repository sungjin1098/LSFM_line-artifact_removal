import csv
import os
from tqdm import tqdm
from skimage import io
from skimage.metrics import peak_signal_noise_ratio, structural_similarity

gt_dir = './My_result_Our_method/1216/data1216_input_Y_110vol_ExcludePSF.tif'
img_dir = './My_result_Our_method/1216/data1216_test_output_3D.tif'
csv_dir = './My_result_Our_method/1216/data1216_value.csv'

f = open(csv_dir, "w")
writer = csv.writer(f)

gt_3D = io.imread(gt_dir)
img_3D = io.imread(img_dir)

PSNR_list = []
SSIM_list = []

for i in tqdm(range(gt_3D.shape[0])):
    gt_2D = gt_3D[i]
    img_2D = img_3D[i]

    PSNR = peak_signal_noise_ratio(gt_2D, img_2D)
    SSIM = structural_similarity(gt_2D, img_2D)

    save = [i, PSNR, SSIM]
    writer.writerow(save)

    PSNR_list.append(PSNR)
    SSIM_list.append(SSIM)

f.close()

PSNR_mean = sum(PSNR_list) / len(PSNR_list)
SSIM_mean = sum(SSIM_list) / len(SSIM_list)

os.rename(csv_dir, f'{csv_dir[:-4]}_P_{PSNR_mean:.3f}_S_{SSIM_mean:.3f}{csv_dir[-4:]}')